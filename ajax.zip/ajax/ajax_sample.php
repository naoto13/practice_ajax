<?php

if(!empty($_POST)){
    echo print_r($_POST, true);
}